/* ========================================================================================================
   DATABASE : ORACLE
   ========================================================================================================
   DML Query 'Delete' is deleting data from table 'JUNKMAIL' only when these two conditions are met together
   using 'AND' clause.
   1. Column 'samfam' value is NULL.
   2. The id of the mail is in the list of any members 'samfam'
   ========================================================================================================
*/

CREATE TABLE JunkMail(Name varchar2(20), Address varchar2(10), ID Number(5), SameFam Number(10));
INSERT INTO JunkMail VALUES('Alice'  , 'A' , 10 , NULL);
INSERT INTO JunkMail VALUES('Bob'    , 'B' , 15 , NULL);
INSERT INTO JunkMail VALUES('Carmen' , 'C' , 22 , NULL);
INSERT INTO JunkMail VALUES('Diego'  , 'A' , 9  , 10);
INSERT INTO JunkMail VALUES('Ella'   , 'B' , 3  , 15);
INSERT INTO JunkMail VALUES('Farkhad', 'D' , 11 , NULL);

DELETE FROM junkmail 
WHERE samefam is null 
AND id IN ( SELECT samefam FROM junkmail);