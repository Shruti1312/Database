/* ========================================================================================================
   DATABASE : ORACLE
   ========================================================================================================
   In the SELECT query, I have used 'GROUP BY' on column 'worker_id' with conditional clause of 
   'WHERE'(step_status = 'C') which will result into return of all the distinct worker_id with their 
   respective number of count with only 'Completed Status'. On top of that "Having" clause with count(*) 
   will filter the above result and will return only the worker_ids that has total count of 1 and 'C' Status.
   ========================================================================================================
*/

CREATE TABLE WorkOrder(workorder_id varchar2(10), step_num Number(5), step_status char(1));

INSERT INTO WorkOrder VALUES('P100' , 0 , 'C');
INSERT INTO WorkOrder VALUES('P100' , 1 , 'W');
INSERT INTO WorkOrder VALUES('P100' , 2 , 'W');
INSERT INTO WorkOrder VALUES('P201' , 0 , 'C');
INSERT INTO WorkOrder VALUES('P201' , 1 , 'C');
INSERT INTO WorkOrder VALUES('P333' , 0 , 'W');
INSERT INTO WorkOrder VALUES('P333' , 1 , 'W');
INSERT INTO WorkOrder VALUES('P333' , 2 , 'W');
INSERT INTO WorkOrder VALUES('P333' , 3 , 'W');

SELECT workorder_id
FROM workorder
WHERE step_status = 'C'
GROUP BY workorder_id
HAVING count(*) = 1;