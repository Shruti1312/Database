/*====================================================================================================
   DATABASE USED : ORACLE
  
   'Before Insert' Trigger is used On table 'HotelStays'.
   Every data inserted will be validated against some checks and if found incorrect, 
   then a user defined exception is thrown and it will notify the user of the incorrect data and will not 
   insert that record in the table 'HotelStays'. 
   1. First Validation - before inserting a record in the table, it is checked if the arrival date is not 
      any date later than departure date.
   2. Second Validation - I am selecting the count of records already existing in the booking records with       dates that clashes with the date range we are going to insert. If count comes to be non-zero number,       that means clashes exists and then exception is thrown stating the problme to the user.
  ======================================================================================================
*/

CREATE TABLE HotelStays
(roomNum INTEGER NOT NULL,
arrDate DATE NOT NULL,
depDate DATE NOT NULL,
guestName CHAR(30) NOT NULL,
PRIMARY KEY (roomNum, arrDate));

CREATE OR REPLACE TRIGGER chk_guest
BEFORE INSERT
ON HotelStays
FOR EACH ROW
DECLARE
x BOOLEAN;
clash_count NUMBER(1) := 0;
Invalid_Exception EXCEPTION;
OverLap_Exception EXCEPTION;
BEGIN
SELECT COUNT(*)
  INTO   clash_count 
  FROM   HotelStays
  WHERE  (roomNum = :new.roomNum)
  AND    ((arrDate > :new.arrDate AND arrDate < :new.depDate)
  OR     (depdate > :new.arrDate and depDate < :new.depDate));

IF ( :new.arrDate > :new.depDate ) THEN
raise invalid_exception;
END IF;
IF (clash_count > 0) THEN
raise OverLap_Exception;
END IF;

EXCEPTION
WHEN Invalid_Exception THEN raise_application_error(-20001,'Arrival date can not be later than departure date');
WHEN OverLap_Exception THEN raise_application_error(-20002,'Already booking exists from these Dates');
WHEN OTHERS THEN raise_application_error(-20003,'Something went wrong');
END;
/
