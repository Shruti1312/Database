/* ========================================================================================================
   DATABASE : ORACLE
   ========================================================================================================
   USING INTERSECT RELATION
    
   Below DQL Query is working in these steps 
   Step 1 : Select all distinct chefs that serve 'Apple Pie'.
   Step 2 : Select all distinct chefs that serve 'Upside down pineapple cake'
   STEP 3 : Select all distinct chefs that serve ''Creme brulee'
   STEP 4 : Select the Chefs that are common in the result of all above three queries.   
   ========================================================================================================
*/

CREATE TABLE MasterChef(Chef varchar2(10), Dish varchar2(40));
INSERT INTO MASTERCHEF values('A' ,  'Mint chocolate brownie'      );
INSERT INTO MASTERCHEF values('B' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('B' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('B' ,  'Mint chocolate brownie'      );
INSERT INTO MASTERCHEF values('C' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('C' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('D' ,  'Apple pie'                   );
INSERT INTO MASTERCHEF values('D' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('D' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('E' ,  'Apple pie'                   );
INSERT INTO MASTERCHEF values('E' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('E' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('E' ,  'Bananas Foster'              );

SELECT DISTINCT chef FROM masterchef WHERE dish Like 'Creme brulee'
INTERSECT
SELECT DISTINCT chef FROM masterchef WHERE dish Like 'Upside down pineapple cake'
INTERSECT
SELECT DISTINCT chef FROM masterchef WHERE dish Like 'Apple pie';