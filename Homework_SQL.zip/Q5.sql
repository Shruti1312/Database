/* ========================================================================================================
   DATABASE : ORACLE
   ========================================================================================================
   USING DIVISION RELATION

   Below DQL Query (Select) is selecting all the chefs that meet the requirement of the dishes in Required table.
   First, selecting all the chefs that meet any dish in Required table and then grouping them by 'Chef' will give 
   the COUNT PER REQUIRED_DISH and if the count is equal to the number of dishes in required table that means 
   chef passes the criteria for all dishes.

   It is basically a division operation where table of masterchef with two columns 'Chef' and 'Dish' is divided 
   by another table 'Required' with only one column i.e 'Dish' , which ultimately returns only the rows in masterchef which 
   meets complete column from 'required' table. 
    
   ========================================================================================================
*/


CREATE TABLE MasterChef(Chef varchar2(10), Dish varchar2(40));
INSERT INTO MASTERCHEF values('A' ,  'Mint chocolate brownie'      );
INSERT INTO MASTERCHEF values('B' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('B' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('B' ,  'Mint chocolate brownie'      );
INSERT INTO MASTERCHEF values('C' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('C' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('D' ,  'Apple pie'                   );
INSERT INTO MASTERCHEF values('D' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('D' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('E' ,  'Apple pie'                   );
INSERT INTO MASTERCHEF values('E' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('E' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('E' ,  'Bananas Foster'              );

CREATE TABLE Required(dish varchar2(30));
INSERT INTO Required VALUES('Apple pie');
INSERT INTO Required VALUES('Upside down pineapple cake');
INSERT INTO Required VALUES('Creme brulee');

SELECT chef 
FROM Masterchef 
WHERE dish IN (SELECT dish FROM Required)
GROUP BY chef
HAVING COUNT(*) = ( SELECT COUNT (*) FROM Required);
