/* ========================================================================================================
   DATABASE : ORACLE
   ========================================================================================================
   USING DIVISION RELATION
    
   Below DQL Query is working in two parts. 
   Part 1 : Select all the chefs that does not serve any dish in required Dish.
   Part 2 : Select all the chefs except the one who does not meet the above list.  

   It is basically a division operation where table of masterchef with two columns 'Chef' and 'Dish' is divided 
   by another table 'Required' with only one column i.e 'Dish' , which ultimately returns only the rows in masterchef which 
   meets complete column from 'required' table. 
    
   ========================================================================================================
*/


CREATE TABLE MasterChef(Chef varchar2(10), Dish varchar2(40));
INSERT INTO MASTERCHEF values('A' ,  'Mint chocolate brownie'      );
INSERT INTO MASTERCHEF values('B' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('B' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('B' ,  'Mint chocolate brownie'      );
INSERT INTO MASTERCHEF values('C' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('C' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('D' ,  'Apple pie'                   );
INSERT INTO MASTERCHEF values('D' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('D' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('E' ,  'Apple pie'                   );
INSERT INTO MASTERCHEF values('E' ,  'Upside down pineapple cake'  );
INSERT INTO MASTERCHEF values('E' ,  'Creme brulee'                );
INSERT INTO MASTERCHEF values('E' ,  'Bananas Foster'              );

CREATE TABLE Required(dish varchar2(30));
INSERT INTO Required VALUES('Apple pie');
INSERT INTO Required VALUES('Upside down pineapple cake');
INSERT INTO Required VALUES('Creme brulee');

SELECT DISTINCT x.chef
FROM masterchef x
WHERE NOT EXISTS (
SELECT *
FROM required y
WHERE NOT EXISTS (
SELECT *
FROM masterchef z
WHERE (z.chef = x.chef)
AND (z.dish = y.dish)));