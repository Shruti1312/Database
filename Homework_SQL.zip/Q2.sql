/* =========================================================================================
   DATABASE : ORACLE
   ========================================================================================= 
   In the SELECT query, I have used 'GROUP' function with the aggregate'COUNT' that would 
   return all classes with the total number of entries for that particular class.
   'Order by' will order the above result in ascending number by the total count/per class.
   =========================================================================================
*/


CREATE TABLE Enrollment(SID number(10), ClassName varchar(10), Grade varchar(1));

INSERT INTO Enrollment VALUES(123,  'ART123',    'A');
INSERT INTO Enrollment VALUES(123,  'BUS456',    'B');
INSERT INTO Enrollment VALUES(666,  'REL100',    'D');
INSERT INTO Enrollment VALUES(666,  'ECO966',    'A');
INSERT INTO Enrollment VALUES(666,  'BUS456',    'B');
INSERT INTO Enrollment VALUES(345,  'BUS456',    'A');
INSERT INTO Enrollment VALUES(345,  'ECO966',    'F');

SELECT classname, count(*) Total FROM enrollment GROUP BY(classname) ORDER BY Total;